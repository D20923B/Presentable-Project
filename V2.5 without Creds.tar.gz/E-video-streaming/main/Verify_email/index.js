const express = require('express')
const router = express.Router()
const jwt = require('jsonwebtoken');
const path = require('path');
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const dotenv = require('dotenv');
dotenv.config();

router.get('/verify_email',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'Email_verify.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

router.post('/email_verify',async(req,res)=>{
  console.log('email_verify',req.body)

  if(req.cookies.UserSession==undefined)
  {
    //incase there is no cookie
    res.redirect('/')
  }
  else
  {
    let Userdata=jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY)
    let response =await User_database_handler_functions.get_user_data(Userdata.email)
    if(response[0].Otp==req.body.Otp)
    {
      let result = await User_database_handler_functions.change_email_veryfied(Userdata.email)
      if(result==true)
      {
        if(response[0].admin==true)
        {
          res.redirect('/admin_panel')
        }
        else
        {
          res.redirect('/home/0')
        }
      }
      else
      {
        res.send('Erro')
      }
    }
    else
    {
      res.send('Otp is not valid')
    }
  }

})


module.exports=router
