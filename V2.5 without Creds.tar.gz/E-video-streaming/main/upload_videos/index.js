const express = require('express');
const router = express.Router();
const dotenv = require('dotenv');
const path = require('path');
const jwt = require('jsonwebtoken');
const multer  = require('multer')
const fs = require('fs')
dotenv.config();

const Video_detabase_handler = require('./../../DataBase/Video_detabase_handler_functions.js')
const User_detabase_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')

const fileStoreageEngine = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './videos/');
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
});


var upload = multer({storage:fileStoreageEngine })


router.get('/upload_video',(req,res)=>{
  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'upload_video.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            console.log(err)
        }
    });
})


router.post('/upload_video', upload.single('file'),async(req, res)=>{
  if(req.cookies.UserSession==undefined)
  {
    res.redirect('./')
  }
  else
  {
    let Userdata=jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY)
    let response = await User_detabase_handler_functions.get_user_data(Userdata.email)
    if(response[0].admin==false)
    {
      console.log(req.file)
      res.send('unathorised')
      fs.unlinkSync('./'+req.file.path)
    }
    else if(response[0].admin==true)
    {
      Video_detabase_handler.insert(req.body.name,req.file.path,Userdata.email,req.body.description)
      res.send('Video Uploaded')
      Video_detabase_handler.show()
    }
  }
});







module.exports=router
