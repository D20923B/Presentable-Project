const express = require('express')
const app = express()
const router = express.Router()
const cookieParser = require('cookie-parser')
const bodyParser = require('body-parser')
const dotenv = require('dotenv');
const path = require('path');


const Sign_up = require('./sign_up/index.js')
const Verify_email = require('./Verify_email/index.js')
const Sign_in = require('./sign_in/index.js')
const Reset_password = require('./Reset_password/index.js')
const Remove_account = require('./Remove_account/index.js')
const Admin_sign_up = require('./admin_sign_up/index.js')
const Upload_video = require('./upload_videos/index.js')
const Home_page = require('./home_page/index.js')
const Delete_video = require('./Delete_video/index.js')
const Admin_panel = require('./admin_panel/index.js')
const Sign_out = require('./sign_out/index.js')
const Get_comments = require('./Get_comments/index.js')
const Post_comment = require('./post_comment/index.js')
const Complaint = require('./report_video/index.js')


app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json())
app.use(cookieParser())
app.use(router)
app.use(Sign_up)
app.use(Verify_email)
app.use(Sign_in)
app.use(Reset_password)
app.use(Remove_account)
app.use(Admin_sign_up)
app.use(Upload_video)
app.use(Home_page)
app.use(Delete_video)
app.use(Admin_panel)
app.use(Sign_out)
app.use(Get_comments)
app.use(Post_comment)
app.use(Complaint)
dotenv.config();



router.get('/',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'Main.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });
})




app.listen(process.env.PORT)
