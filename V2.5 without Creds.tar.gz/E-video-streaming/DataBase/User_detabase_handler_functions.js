var MongoClient = require('mongodb').MongoClient;
const dotenv = require('dotenv');
dotenv.config();
var url = `mongodb+srv://${process.env.mongodb_Username}:${process.env.mongodb_Password}@cluster0.eiipt1t.mongodb.net/?retryWrites=true&w=majority`;



async function run()
{
  MongoClient.connect(url,(err,res)=>{
    if(err)
    {
      console.log('err is',err)
    }
    else
    {
      let db = res.db('Video-streamer')
      db.createCollection('Users',(err,res)=>{
        if(res)
        {
          console.log('Created db',res)
        }
        else
        {
          console.log('Connected to Already Existing Database')
        }
        res.close()
      })
      //res.close()
    }
  })
}

async function insert(username,password,address,email,Phone_number,Otp)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('err is',err)
      }
      else
      {
        let db = res.db('Video-streamer')
        let datas={username:username,password:password,address:address,email:email,Phone_number:Phone_number,Otp:Otp,email_veryfied:false,admin:false}
        db.collection("Users").insertOne(datas, function(err, res)
        {
          if(res)
          {
            console.log("data inserted");
            data(true)
          }
          else
          {
            console.log(err)
            data(false)
            res.close()
          }
        });
        //res.close()
      }
    })
  })
  return check
}

async function show()
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        db.collection("Users").find({}).toArray(function(err, result)
        {
          if(err)
          {
            data(err)
          }
          else
          {
            data(result);
          }
          res.close()
        });
      }
    })
  })
  console.log(check)
  return check
}


async function get_user_data(email)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={email:email}
        db.collection('Users').find(query).toArray((err,result)=>{
          if(err)
          {
            console.log(err)
          }
          else
          {
            data(result)
          }
          res.close()
        })
      }
    })
  })
  return check
}


async function change_email_veryfied(email)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={email:email}
        let newvalues = { $set: {email_veryfied: true } };
        db.collection("Users").updateOne(query, newvalues, function(err, res) {
          if(err)
          {
            data(err)
          }
          else
          {
            data(true);
            res.close()
          }
        });
      }
    })
  })
  return check
  console.log(1,check)
}


async function insert_admin_user(username,password,address,email,Phone_number,Otp)
{
  let check =await new Promise(function(response)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('err is',err)
      }
      else
      {
        let db = res.db('Video-streamer')
        let data={username:username,password:password,address:address,email:email,Phone_number:Phone_number,Otp:Otp,email_veryfied:false,admin:true}
        console.log(data)
        db.collection("Users").insertOne(data, function(err, res)
        {
          if(res)
          {
            response(true)
          }
          else
          {
            response(err)
          }
          res.close()
        });
      }
    })
  })
  return check
}


async function update_password(email,new_password)
{
  let check =await new Promise(function(response)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={email:email}
        let newvalues = { $set: {password: new_password } };
        db.collection("Users").updateOne(query, newvalues, function(err, res) {
          if(err)
          {
            response(err)
          }
          else
          {
            response(true)
          }
          res.close()
        });
      }
    })
  })
  return check
}


async function update_Otp(email,otp)
{
  let check =await new Promise(function(response)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={email:email}
        let newvalues = { $set: {Otp: otp } };
        db.collection("Users").updateOne(query, newvalues, function(err, res) {
          if(err)
          {
            response(err)
          }
          else
          {
            response(true)
          }
          res.close()
        });
      }
    })
  })
  return check
}


async function Remove_account(email)
{
  let check =await new Promise(function(response)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={email:email}
        db.collection("Users").deleteOne(query, function(err, obj)
        {
          if(err)
          {
            response(false)
          }
          else
          {
            response(true)
          }
          res.close()
        });
      }
    })
  })
  return check
}


async function drop_Users()
{
  MongoClient.connect(url,(err,res)=>{
    if(err)
    {
      console.log('cant connect',err)
    }
    else
    {
      let db=res.db('Video-streamer')
      db.collection("Users").drop(function(err, res) {
        if(err)
        {
          console.log(err)
        }
        else
        {
          console.log('collection deleted')
        }
        res.close()
      });
    }
  })
}


async function Check_Username(username)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={username:username}
        db.collection('Users').find(query).toArray((err,result)=>{
          if(err)
          {
            console.log(err)
          }
          else
          {
            data(result)
          }
          res.close()
        })
      }
    })
  })
  return check
}


//drop_Users()
//show()

exports.Check_Username=Check_Username
exports.Remove_account=Remove_account
exports.run=run
exports.insert=insert
exports.get_user_data=get_user_data
exports.change_email_veryfied=change_email_veryfied
exports.insert_admin_user=insert_admin_user
exports.update_password=update_password
exports.update_Otp=update_Otp
