const express = require('express')
const router = express.Router()
const jwt = require('jsonwebtoken');
const path = require('path');
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const Email_functions = require('./../../External_api/sending_otp_mail.js')

//major bug in mongodb


router.get('/sign_up',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'sign_up.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            console.log(err)
        }
    });

})


router.post('/sign_up',async (req,res)=>{
  console.log('sign_up',req.body)

  let username = await User_database_handler_functions.get_user_data(req.body.email)

  if(username.length==0)
  {

    let otp=Math.floor(100000+Math.random()*9000000)
    Email_functions.sending_otp_to_mail(req.body.email,otp)
    console.log(otp)
    let response = await User_database_handler_functions.insert(req.body.username,req.body.password,req.body.address,req.body.email,req.body.Phone_number,otp)
    if(response==true)
      {

        let jwtSecretKey = process.env.JWT_SECRET_KEY;

        let data = {
            email:req.body.email,
            password:req.body.password
        }

        let token = jwt.sign(data, jwtSecretKey);
        res.cookie("UserSession", token);

        res.redirect('/verify_email');
    }
    else
    {
      res.send('Error Occured Please contact support')
    }

  }
  else
  {
    res.send('Email Already Exists')
  }

})

module.exports=router
