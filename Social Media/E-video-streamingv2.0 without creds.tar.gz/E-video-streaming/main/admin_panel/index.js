const express = require('express')
const path = require('path')
const router = express.Router()

router.get('/admin_panel',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'admin_panel.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            console.log(err)
        }
    });
  }
)


module.exports=router
