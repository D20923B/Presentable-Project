const express = require('express');
const router=express.Router();
const path = require('path');
const methods = require('./../scripts/admin_signup_methods.js')
const jwt = require('jsonwebtoken');
const md5 = require('md5')

router.get('/admin_signup',(req,res)=>{


  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'admin_signup.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

router.post('/admin_signup',(req,res)=>{
  password=md5(req.body.password)
  methods.store_data(req.body.username,password,req.body.address,req.body.email,req.body.phone_number)

  let jwtSecretKey = process.env.JWT_SECRET_KEY;

  let data = {
      email:req.body.email,
      password:req.body.password
  }

  const token = jwt.sign(data, jwtSecretKey);
  res.cookie("UserSession", token);
  res.redirect('http://localhost:8000/admin_email_verify')

})

router.get('/admin_email_verify',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'Otp_verification.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

module.exports=router;
