const db=require("./../database/database.js");
const md5=require('md5');

async function check_email(email)
{

  let check =await new Promise(function(result)
  {
      db.all(`SELECT * FROM UserDatabase WHERE email='${email}'`,(err,row)=>{

        if(row.length==1)
        {
          result(true)
        }
        else if(row.length==0)
        {
          result(false)
        }

      })
  })
  return check

}

async function update_OTP(email,otp)
{
  db.run(`UPDATE UserDatabase SET email_otp='${otp}' WHERE email='${email}'`)
}

async function update_password(email,otp,new_password)
{
  new_password=md5(new_password)
  let check =await new Promise(function(result)
  {
      db.all(`SELECT * FROM UserDatabase WHERE email='${email}' AND email_otp=${otp}`,(err,row)=>{
        if(row)
        {
          db.run(`UPDATE UserDatabase SET password='${new_password}' WHERE email='${email}'`)
          result(true)
        }
        else
        {
          result(false)
        }

      })
  })
  return check
}

exports.check_email=check_email
exports.update_OTP=update_OTP
exports.update_password=update_password
