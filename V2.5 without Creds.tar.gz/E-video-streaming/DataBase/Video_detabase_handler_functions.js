var MongoClient = require('mongodb').MongoClient;
const dotenv = require('dotenv');
dotenv.config();
var url = `mongodb+srv://${process.env.mongodb_Username}:${process.env.mongodb_Password}@cluster0.eiipt1t.mongodb.net/?retryWrites=true&w=majority`;



async function run()
{
  MongoClient.connect(url,(err,res)=>{
    if(err)
    {
      console.log('err is',err)
    }
    else
    {
      let db = res.db('Video-streamer')
      db.createCollection('Video-database',(err,res)=>{
        if(res)
        {
          console.log('Created db',res)
        }
        else
        {
          console.log('Connected to Already Existing Database')
        }
        res.close()
      })
      //res.close()
    }
  })
}

async function insert(video_file_name,video_file_location,video_file_uploaded_by,description)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('err is',err)
      }
      else
      {
        let db = res.db('Video-streamer')
        let datas={
          video_file_name:video_file_name,
          video_file_location:video_file_location,
          video_file_uploaded_by:video_file_uploaded_by,
          description:description
          }
        db.collection("Video-database").insertOne(datas, function(err, response)
        {
          if(response)
          {
            console.log("data inserted");
            data(true)
          }
          else
          {
            console.log(err)
            data(false)
          }
          res.close()
        });
        //res.close()
      }
    })
  })
  return check
}


async function get_video_data(video_file_name)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={video_file_name:video_file_name}
        db.collection('Video-database').find(query).toArray((err,result)=>{
          if(err)
          {
            console.log(err)
          }
          else
          {
            data(result)
          }
          res.close()
        })
      }
    })
  })
  return check
}

async function post_comment(video_file_name,new_comment)
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
        data(false)
      }
      else
      {
        let db=res.db('Video-streamer')
        db.collection("Video-database").updateOne({video_file_name:video_file_name},{$push:{'comments':new_comment}});
        data(true)
      }
    })
  })
  return check
}


async function Remove_video(video_file_name,video_file_location,video_file_uploaded_by,description)
{
  let check =await new Promise(function(response)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        let query={
          video_file_name:video_file_name,
          video_file_location:video_file_location,
          video_file_uploaded_by:video_file_uploaded_by,
          description:description
        }
        db.collection("Video-database").deleteOne(query, function(err, obj)
        {
          if(err)
          {
            response(false)
          }
          else
          {
            response(true)
          }
          res.close()
        });
      }
    })
  })
  return check
}


async function drop_collection()
{
  MongoClient.connect(url,(err,res)=>{
    if(err)
    {
      console.log('cant connect',err)
    }
    else
    {
      let db=res.db('Video-streamer')
      db.collection("Video-database").drop(function(err, response) {
        if(err)
        {
          console.log(err)
        }
        else
        {
          console.log('collection deleted')
        }
        res.close()
      });
    }
  })
}

async function show()
{
  let check =await new Promise(function(data)
  {
    MongoClient.connect(url,(err,res)=>{
      if(err)
      {
        console.log('cant connect',err)
      }
      else
      {
        let db=res.db('Video-streamer')
        db.collection("Video-database").find({}).toArray(function(err, result)
        {
          if(err)
          {
            data(err)
          }
          else
          {
            data(result);
          }
          res.close()
        });
      }
    })
  })
  return check
}

//need to deal with space values
//drop_collection()

//insert(1,2,3,4)
//post_comment('name',9)
//show()

exports.insert=insert
exports.show=show
exports.get_video_data=get_video_data
exports.post_comment=post_comment
exports.Remove_video=Remove_video
