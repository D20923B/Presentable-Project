const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs')
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')
const User_database_handler_functions =  require('./../../DataBase/User_detabase_handler_functions.js')

router.get('/delete_video',(req,res)=>{
  if(req.cookies.UserSession==undefined)
  {
    res.redirect('/')
  }
  else
  {
    var options = {
          root: path.join(__dirname,'./../../html_templates')
      };

      var fileName = 'Delete_video.html';
      res.sendFile(fileName, options, function (err) {
          if (err) {
              next(err);
          }
      });
  }
})

router.post('/delete_video',async(req,res)=>{
  let Userdata=jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY)
  let result=await User_database_handler_functions.get_user_data(Userdata.email)
  if(result[0].admin==true)
  {
    let response1  =await Video_detabase_handler_functions.get_video_data(req.body.name)
    let response = await Video_detabase_handler_functions.Remove_video(req.body.name)
    console.log(req.body)
    fs.unlinkSync(response1[0].video_file_location)
    res.send(response)
  }
  else
  {
    res.send('User not authorised')
  }

})











module.exports=router
