const express = require('express')
const router = express.Router()
const jwt = require('jsonwebtoken');
const path = require('path');
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const dotenv = require('dotenv');
const md5 = require('md5')
dotenv.config();

router.get('/sign_in',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'sign_in.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})



router.post('/sign_in',async(req,res)=>{
  let response = await User_database_handler_functions.get_user_data(req.body.email)
  if(response.length==0)
  {
    res.send('EMAIL or password Incorrect')
  }
  else
  {
    if(response[0].password==md5(req.body.password))
    {

      let data = {
          email:req.body.email
      }

      let token = jwt.sign(data,process.env.JWT_SECRET_KEY);
      res.cookie("UserSession", token);

      if(response[0].email_veryfied==false)
      {
        res.redirect('/verify_email')
      }
      else if (response[0].email_veryfied==true)
      {
        if(response[0].admin==true)
        {
          res.redirect('/admin_panel')
        }
        else
        {
          res.redirect('/home/0')
        }
      }
    }
    else
    {
      res.send('EMAIL or password Incorrect')
    }
  }
})


module.exports=router
