const express = require('express');
const router = express.Router();
const path = require('path');
const jwt = require('jsonwebtoken');
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')



router.get('/home/:id',async(req,res)=>{
  let count = parseInt(req.params.id)+1
  let menu =await Video_detabase_handler_functions.show()
  if(req.cookies.UserSession==undefined)
  {
    res.redirect('/')
  }
  else if(count>menu.length)
  {
    res.send(`<body>
    <button onclick="myFunction1()">Go Back</button>
    </body>
    <script>
    function myFunction1()
    {
      location.replace("http://localhost:8000/home/${parseInt(req.params.id)-1}")
    }
    </script>`
    )
  }
  else
  {
        res.send(`<body>
          <h1>${menu[count-1].video_file_name}</h1>
        <video width="800" height="400" controls>
          <source src="http://localhost:8000/video/${count-1}" type="video/mp4">
          Your browser does not support the video tag.
        </video>
        <br>
        <button onclick="myFunction()">next</button>
        <button onclick="myFunction1()">prev</button>

        <script>
        function myFunction()
        {
          location.replace("http://localhost:8000/home/${count}")
        }
        function myFunction1()
        {
          location.replace("http://localhost:8000/home/${parseInt(req.params.id)-1}")
        }
        </script>
        </body>

        `)
  }
})


router.get('/video/:id',async(req,res)=>{

  let menu =await Video_detabase_handler_functions.show()
  let raw_file_name = (menu[req.params.id].video_file_location).split('/')[1]

    var options = {
          root: path.join(__dirname,'./../../videos')
      };

      var fileName = raw_file_name;
      res.sendFile(fileName, options, function (err) {
          if (err) {
            console.log(err)
            //next(err)
          }
      });

})








module.exports=router
