const express = require('express');
const router = express.Router();
const dotenv = require('dotenv');
const path = require('path');
const jwt = require('jsonwebtoken');
const md5 = require('md5')
dotenv.config();
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const Email_functions=require('./../../External_api/sending_otp_mail.js')


router.get("/Reset_password",(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'Reset_password.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})



router.post('/Reset_password',async(req,res)=>{
  let otp=Math.floor(100000+Math.random()*9000000)
  console.log(otp)
  let result=await User_database_handler_functions.get_user_data(req.body.email)
  if(result.length>0)
  {
    Email_functions.sending_otp_to_mail(req.body.email,otp)
    User_database_handler_functions.update_Otp(req.body.email,otp)

    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    let data = {
        email:req.body.email
    }

    let token = jwt.sign(data, jwtSecretKey);
    res.cookie("Password_reset_Session", token);

    res.redirect('/Reset_password/data');
  }
  else
  {
    res.send('Email Does Not Existed')
  }
})





router.get("/Reset_password/data",(req,res)=>{
  if(req.cookies.Password_reset_Session==undefined)
  {
    res.redirect('/Reset_password')
  }
  else
  {
    var options = {
          root: path.join(__dirname,'./../../html_templates')
      };

      var fileName = 'Reset_password_data.html';
      res.sendFile(fileName, options, function (err) {
          if (err) {
              next(err);
          }
      });
  }
})


//bug in reset password

router.post('/Reset_password/data',async(req,res)=>{
  let Userdata=jwt.verify(req.cookies.Password_reset_Session,process.env.JWT_SECRET_KEY)
  let response =await User_database_handler_functions.get_user_data(Userdata.email)
  console.log('response is',response[0].username)
  if(response[0].Otp==req.body.Otp)
  {
    User_database_handler_functions.update_password(response[0].email,md5(req.body.new_password))
    res.send('Otp accepted')
  }
  else
  {
    res.send('OTP is Wrong')
  }
})



module.exports=router
