const express = require('express');
const router=express.Router();
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const methods = require('./../scripts/sign_in_methods.js')
const path = require('path');


router.get('/',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'sign_in.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

//sign in using email
router.get('/email',(req,res)=>{
  res.send('sign in using email');
})

//forget password
router.get('/forget_password',(req,res)=>{
  res.send('forget password');
})

//sign in data
router.post('/sign_in_data',async(req,res)=>{


  let creds;
  let email_activation;

  if(await methods.login_creds(req.body.email,req.body.password)==true)
  {

    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    let data = {
        email:req.body.email,
        password:req.body.password
    }

    const token = jwt.sign(data, jwtSecretKey);
    res.cookie("UserSession", token);

    if(await methods.email_activated(req.body.email)==false)
    {
      res.redirect('/signup/verify_email')
    }
    else if (await methods.email_activated(req.body.email)==true)
    {
      var options = {
            root: path.join(__dirname,'./../html_templates/Website_home')
        };

        var fileName = 'Website_home.html';
        res.sendFile(fileName, options, function (err) {
            if (err) {
                next(err);
            }
        });
    }

  }
  else
  {
    res.send('Creds Wrong')
  }

})

module.exports=router;
