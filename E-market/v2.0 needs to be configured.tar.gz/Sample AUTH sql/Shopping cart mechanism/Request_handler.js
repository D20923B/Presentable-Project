const link_list = require('./link_list.js')
const item_database = new link_list.link_list()


function add(item_name,item_price,image_path)
{
  item_database.add(item_name,item_price,image_path)
}

function show()
{
  console.log(item_database)
}

function delete_items(item_name)
{
  item_database.remove(item_name)
}

async function check_empty()
{
  let res =await item_database.check_empty()
  return res
}

async function entire_item_history()
{
  let res = await item_database.entire_item_history()
  return res
}

async function next(item_name)
{
  let res = await item_database.next(item_name)
  return res
}

async function previous(item_name)
{
  let res = await item_database.previous(item_name)
  return res
}

exports.add=add
exports.show=show
exports.delete_items=delete_items
exports.check_empty=check_empty
exports.next=next
exports.previous=previous
exports.entire_item_history=entire_item_history
//different functions and class functions to work here
