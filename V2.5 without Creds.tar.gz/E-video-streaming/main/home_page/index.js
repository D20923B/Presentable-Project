const express = require('express');
const router = express.Router();
const path = require('path');
const jwt = require('jsonwebtoken');
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')



router.get('/home/0',async(req,res)=>{
  let menu =await Video_detabase_handler_functions.show()
  if(req.cookies.UserSession==undefined)
  {
    res.redirect('/')
  }
  else
  {
    var options = {
          root: path.join(__dirname,'./../../html_templates')
      };

      var fileName = 'Home_screen.html';
      res.sendFile(fileName, options, function (err) {
          if (err) {
              console.log(err)
          }
      });
  }
})


router.get('/video/:id',async(req,res)=>{

  let menu =await Video_detabase_handler_functions.show()
  if(menu.length!=0)
  {
    let raw_file_name = (menu[req.params.id].video_file_location).split('/')[1]

      var options = {
            root: path.join(__dirname,'./../../videos')
        };

        var fileName = raw_file_name;
        res.sendFile(fileName, options, function (err) {
            if (err) {
              console.log(err)
              //next(err)
            }
        });
  }
  else
  {
    var options = {
          root: path.join(__dirname,'./../../videos')
      };

      var fileName = "Nodata.mp4";
      res.sendFile(fileName, options, function (err) {
          if (err) {
            console.log(err)
            //next(err)
          }
      });
  }


})








module.exports=router
