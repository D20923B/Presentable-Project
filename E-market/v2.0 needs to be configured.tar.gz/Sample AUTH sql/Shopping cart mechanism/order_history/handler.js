const link_list = require('./order_history.js')
const item_database = new link_list.link_list()

async function entire_order_history()
{
  let res = await item_database.entire_order_history()
  return res
}


function add(item_name,item_quantity,user_name)
{
  item_database.add(item_name,item_quantity,user_name)
}

function show()
{
  console.log(item_database)
}

function delete_items(item_name)
{
  item_database.remove(item_name)
}

async function check_empty()
{
  let res =await item_database.check_empty()
  return res
}

async function next(item_name)
{
  let res = await item_database.next(item_name)
  return res
}

async function previous(item_name)
{
  let res = await item_database.previous(item_name)
  return res
}

async function order_history(user_name)
{
  let res = await item_database.order_history(user_name)
  return res
}

function remove(email,item_name)
{
  item_database.remove(email,item_name)
}

exports.add=add
exports.show=show
exports.delete_items=delete_items
exports.check_empty=check_empty
exports.next=next
exports.previous=previous
exports.order_history=order_history
exports.remove=remove
exports.entire_order_history=entire_order_history
//different functions and class functions to work here
