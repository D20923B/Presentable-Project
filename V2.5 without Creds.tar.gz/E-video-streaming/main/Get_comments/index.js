const express = require('express')
const router = express.Router()
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')


router.get('/comments/:id',async(req,res)=>{
  let response =await Video_detabase_handler_functions.show()
  res.send(response[req.params.id])
})




module.exports=router
