const express = require('express')
const router = express.Router()
const path = require('path');
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const Email_functions = require('./../../External_api/sending_otp_mail.js')
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();




router.get('/Remove_account',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'Remove_account.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });
})


router.post('/Remove_account',async(req,res)=>{

  let result=await User_database_handler_functions.get_user_data(req.body.email)
  if(result.length>0)
  {
    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    let data = {
        email:req.body.email
    }

    let token = jwt.sign(data, jwtSecretKey);

    let otp=Math.floor(100000+Math.random()*9000000)
    console.log(otp)
    User_database_handler_functions.update_Otp(req.body.email,otp)
    Email_functions.sending_otp_to_mail(req.body.email,otp)
    res.cookie("Remove_account_Session", token);
    res.redirect('/Remove_account/confirmation');
  }
  else
  {
    res.send('Email Does not Exists')
  }
})



router.get('/Remove_account/confirmation',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'Remove_account_confirmation.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})



router.post('/Remove_account/confirmation',async(req,res)=>{

  if(req.cookies==undefined)
  {
    res.redirect('/Remove_account')
  }
  else
  {
    let Userdata=jwt.verify(req.cookies.Remove_account_Session,process.env.JWT_SECRET_KEY)
    let result=await User_database_handler_functions.get_user_data(Userdata.email)
    if(result.length>0)
    {
      if(result[0].Otp==req.body.otp&&result[0].password==req.body.password)
      {
        User_database_handler_functions.Remove_account(result[0].email)
        res.send('Account deleted')
      }
      else
      {
        res.send('Otp or Password Wrong')
      }
    }
    else
    {
      res.send('Account does not exists')
    }

  }

})

module.exports=router
