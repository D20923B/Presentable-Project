const express = require('express')
const router = express.Router()
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')


router.post('/post_comment',async(req,res)=>{
  if(req.cookies.UserSession==undefined)
  {
    res.send('Not authroised')
  }
  else
  {
    let response =await Video_detabase_handler_functions.show()
    Video_detabase_handler_functions.post_comment(response[req.body.count].video_file_name,req.body.comment)
    res.send('posted')
  }

})




module.exports=router
