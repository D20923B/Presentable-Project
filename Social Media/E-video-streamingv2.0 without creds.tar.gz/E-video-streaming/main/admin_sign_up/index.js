const express = require('express')
const path = require('path')
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken')
const router = express.Router()
const User_database_handler_functions = require('./../../DataBase/User_detabase_handler_functions.js')
const Email_functions = require('./../../External_api/sending_otp_mail.js')
const md5 = require('md5')
dotenv.config();


router.get('/admin_sing_up',(req,res)=>{
  var options = {
        root: path.join(__dirname,'./../../html_templates')
    };

    var fileName = 'admin_sign_up.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });
})


router.post('/admin_sign_up',async(req,res)=>{

  let username = await User_database_handler_functions.get_user_data(req.body.email)

  if(username.length==0)
  {

    let otp=Math.floor(100000+Math.random()*9000000)
    Email_functions.sending_otp_to_mail(req.body.email,otp)
    console.log(otp)
    let response = await User_database_handler_functions.insert_admin_user(req.body.username,md5(req.body.password),req.body.address,req.body.email,req.body.Phone_number,otp)
    if(response==true)
      {

        let jwtSecretKey = process.env.JWT_SECRET_KEY;

        let data = {
            email:req.body.email,
            password:req.body.password
        }

        let token = jwt.sign(data, jwtSecretKey);
        res.cookie("UserSession", token);

        res.redirect('/verify_email');
    }
    else
    {
      res.send('Error Occured Please contact support')
    }
  }
  else
  {
    res.send('Email Already Exists')
  }
})











module.exports=router
