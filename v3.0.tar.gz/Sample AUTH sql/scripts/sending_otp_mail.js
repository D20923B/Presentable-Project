const nodemailer = require('nodemailer');

function sending_opt_to_mail(email,otp)
{
  /*
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  });

  var mailOptions = {
    from: 'process.env.email',
    to: `${email}`,
    subject: 'Email verification ',
    text: `you email is ${otp}`
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
  */
}



function sending_order_details(email,item_name,quantity,address)
{
  /*
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  });

  var mailOptions = {
    from: 'process.env.email',
    to: `${email}`,
    subject: 'Order Summary ',
    text: `Order as been placed for ${item_name} and quantity ${quantity} with address ${address}`
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
  */
}

exports.sending_opt_to_mail=sending_opt_to_mail
exports.sending_order_details=sending_order_details
