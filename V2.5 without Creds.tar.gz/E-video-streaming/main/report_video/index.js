const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
const Video_detabase_handler_functions = require('./../../DataBase/Video_detabase_handler_functions.js')
const Email_functions = require('./../../External_api/sending_otp_mail.js')


router.post('/report_video',async(req,res)=>{

  if(req.cookies.UserSession==undefined)
  {
    res.send('unathorised')
  }
  else
  {
    let video_data = await Video_detabase_handler_functions.show()
    let Userdata=jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY)
    Email_functions.report_video(video_data[req.body.count].video_file_name,req.body.complaint,Userdata.email)
    res.send('done')
  }
  })



module.exports=router
