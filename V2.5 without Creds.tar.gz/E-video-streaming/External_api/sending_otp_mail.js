const nodemailer = require('nodemailer');

function sending_otp_to_mail(email,otp)
{
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  });

  var mailotpions = {
    from: 'process.env.email',
    to: `${email}`,
    subject: 'Email verification ',
    text: `you OTP Code is ${otp}`
  };

  transporter.sendMail(mailotpions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
}


function report_video(video_file_name,complaint,reported_by)
{
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  });

  var mailotpions = {
    from: 'process.env.email',
    to: `${process.env.email}`,
    subject: `${reported_by} reported ${video_file_name}`,
    text: `Reason: ${complaint}`
  };

  transporter.sendMail(mailotpions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
}




exports.sending_otp_to_mail=sending_otp_to_mail
exports.report_video=report_video
