const db=require("./../database/database.js");
const api  =require("./../api's/verification.js")
const send_opt_to_mail =require('./sending_otp_mail.js')
const nodemailer = require('nodemailer');
const md5  =require('md5')


async function check_email(email)
{
   let user_Exists=new Promise(function(myResolve,err)
   {
     db.all(`SELECT * FROM UserDatabase WHERE email='${email}'`,(err,row)=>{
       if(row.length==1)
       {
         myResolve('USER_EXISTS')
       }
       else if (row.length==0)
       {
         myResolve('USER_DOES_NOT_EXISTS')
       }
    })
   })

  let result = await user_Exists
  if(result=='USER_DOES_NOT_EXISTS')
  {
    return false
  }
  else if (result=='USER_EXISTS')
  {
    return true
  }
}


function email_otp(email,otp){

    send_opt_to_mail.sending_opt_to_mail(email,otp)
}


async function verify_email(email,otp)
{
  let user_Exists=new Promise(function(myResolve)
  {
    db.all(`SELECT email_otp FROM UserDatabase WHERE email='${email}'`,(err,row)=>{
        myResolve(row)
   })
  })

  let result = await user_Exists
  if(result[0].email_otp==otp)
  {
    db.run(`UPDATE UserDatabase SET email_veryfied='TRUE' WHERE email='${email}'`)
    return true
  }
  else
  {
    return false
  }
}


async function store_data(username,password,address,email,phone_number,otp)
{
    email_otp(email,otp)
    password=md5(password)
    db.run(`INSERT INTO UserDatabase (username,password,address,email,Phone_number,email_otp,email_veryfied,admin) VALUES('${username}','${password}','${address}','${email}','${phone_number}','${otp}','FALSE','FALSE');`)
    showUserData(); //CHECK DATA
}

function showUserData()
{

  db.each("SELECT * FROM UserDatabase", (err, row) => {
        console.log(row);
    });

}

exports.check_email=check_email
exports.verify_email=verify_email
exports.store_data=store_data
exports.email_otp=email_otp
exports.showUserData=showUserData
