const express = require('express');
const router=express.Router();
const order_history = require('./../Shopping cart mechanism/order_history/handler.js')
const item_database = require('./../Shopping cart mechanism/Request_handler.js')
const User_database = require('./../database/database.js')
const sending_otp_mail = require('./../scripts/sending_otp_mail.js')

router.post('/forgot_Special_key',(req,res)=>{
  send_opt_to_mail.sending_opt_to_mail(process.env.email,process.env.Special_key)
  res.send('special key send to admin email')
})

router.post('/Show_user_database',async(req,res)=>{

  if(req.body.Special_key==process.env.Special_key)
  {
  let user_Exists=new Promise(function(myResolve,err)
  {
    User_database.all(`SELECT * FROM UserDatabase `,(err,row)=>{
      myResolve(row)
   })
  })

  let result = await user_Exists
  res.send(result)
  }
  else
  {
    res.send('Special key not valid')
  }


})
router.post('/Show_order_database',async(req,res)=>{
  console.log(process.env.Special_key)
  if(req.body.Special_key==process.env.Special_key)
  {
    let result = await order_history.entire_order_history()
    res.send(result)
  }
  else
  {
    res.send('Special key not valid')
  }
})

router.post('/item_database',async(req,res)=>{

  if(req.body.Special_key==process.env.Special_key)
  {
    let result =await item_database.entire_item_history()
    res.send(result)
  }
  else
  {
    res.send('Special key not valid')
  }

})

router.post('/sign_out',(req,res)=>{
  res.clearCookie('UserSession');
  res.redirect('/')
})

module.exports=router;
