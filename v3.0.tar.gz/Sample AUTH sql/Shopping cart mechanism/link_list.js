const fs = require('fs')


class Itemlist
{
  constructor(item_name,item_price,item_img,added_by,item_quantity)
  {
    this.item_name = item_name;
    this.item_price = item_price;
    this.item_img = item_img;
    this.added_by=added_by;
    this.item_quantity=item_quantity
    this.next=null;
    this.prev=null;
  }
}



class link_list
{
  constructor()
  {
    this.head=null;
  }

  check_quantity(item_name,require_quantity)
  {
    console.log('req quantity',require_quantity)
    let temp=this.head
    while (temp.item_name!=item_name)
    {
      temp=temp.next
    }
    if(parseInt(require_quantity)<=parseInt(temp.item_quantity))
    {
      temp.item_quantity=temp.item_quantity-require_quantity
      return true
    }
    else
    {
      return false
    }
  }

  get_added_by(item_name)
  {
    let temp =this.head
    while(temp.item_name!=item_name)
    {
      temp=temp.next
    }
    return temp.added_by
  }

  add(item_name,item_price,item_img,added_by,item_quantity)
  {
    console.log('added by',added_by)
    var a = new Itemlist(item_name,item_price,item_img,added_by,item_quantity)
    if(this.head==null)
    {
      a.next==null
    }
    else
    {
      this.head.prev=a
      a.next=this.head
    }
      this.head=a;
    this.show()
  }

  entire_item_history()
  {
    let a={}
    let temp=this.head
    let count=1
    while (temp!=null)
    {
      a[count]=temp.item_name+':'+temp.item_price+':'+temp.item_img
      count++
      temp=temp.next
    }
    return a
  }

  next(item_name)
  {
    let temp=this.head
    while(temp.item_name!=item_name)
    {
      temp=temp.next
    }
    temp=temp.next
    return temp
  }

  previous(item_name)
  {
    let temp=this.head
    console.log('check1',temp)
    while(temp.item_name!=item_name)
    {
      temp=temp.next
    }
    temp=temp.prev
    return temp
  }

  show()
  {
    let temp=this.head
    while(temp!=null)
    {
      console.log(temp)
      temp=temp.next
    }
  }


  remove(item_name)
  {
    let temp=this.head

    while(temp.item_name!=item_name)
    {
      temp=temp.next
    }

    let location = temp.item_img
    fs.unlinkSync(location);


    let temp1 = temp.prev
    let temp2 = temp.next
    if(temp1!=null)
    {
      temp1.next=temp2
    }
    else
    {
      this.head=this.head.next
    }
    if(temp2!=null)
    {
      temp2.prev=temp1
    }

  }
  check_empty()
  {
    return this.head
  }
}

exports.link_list=link_list
