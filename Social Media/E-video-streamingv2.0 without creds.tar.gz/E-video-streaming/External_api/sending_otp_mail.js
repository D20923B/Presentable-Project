const nodemailer = require('nodemailer');

function sending_otp_to_mail(email,otp)
{
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  });

  var mailotpions = {
    from: 'process.env.email',
    to: `${email}`,
    subject: 'Email verification ',
    text: `you OTP Code is ${otp}`
  };

  transporter.sendMail(mailotpions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
}




exports.sending_otp_to_mail=sending_otp_to_mail
