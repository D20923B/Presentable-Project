const express = require('express');
const router=express.Router();
const path = require('path');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const db=require("./../database/database.js");
const multer = require('multer')
const Request_handler=require ('./Request_handler.js')
const Order_History_Handler = require('./order_history/handler.js')

const fileStoreageEngine = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './Shopping cart mechanism/images');
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
});


var upload = multer({storage:fileStoreageEngine })



router.post('/order_history',async(req,res)=>{
  let result = await Order_History_Handler.order_history(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email)
  console.log(result)
  res.send(result)
})

router.post('/delete_order',(req,res)=>{
  Order_History_Handler.remove(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email,req.body.item_name)
  res.send('delete order Received')
})


router.get('/access_store',async (req,res)=>{
  let result  =await Request_handler.check_empty()
  if(result==null)
  {
    res.send('No item on cart')
  }
  else
  {
    res.send(`
      Name:${result.item_name} </br>
      price:${result.item_price} <br>
    <img src="http://localhost:8000/${result.item_img}">

    <form action="/next" method="POST">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Next">
    </form>

    <form action="/buy" method="POST">
    <h5>item quantity</h5>
    <input type="text" id="item_quantity" name="item_quantity">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Buy">
    </form>

    `)
  }
})


router.get('/Shopping%20cart%20mechanism/images/:id',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./images')
    };

    var fileName = `${req.params.id}`;
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})


router.post('/next',async(req,res)=>{
  let result = await Request_handler.next(req.body.item_name)

  if(result==null)
  {
    res.send('End of items')
  }
  else
  {
    res.send(`
      Name:${result.item_name} </br>
      price:${result.item_price} <br>
    <img src="http://localhost:8000/${result.item_img}">

    <form action="/next" method="POST">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Next">
    </form>

    <form action="/previous" method="POST">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Previous">
    </form>

    <form action="/buy" method="POST">
    <h5>item quantity</h5>
    <input type="text" id="item_quantity" name="item_quantity">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Buy">
    </form>
    `)
  }

})


router.post('/previous',async(req,res)=>{
  let result = await Request_handler.previous(req.body.item_name)

  if(result==null)
  {
    res.send('End of items')
  }
  else
  {
    res.send(`
      Name:${result.item_name} </br>
      price:${result.item_price} <br>
    <img src="http://localhost:8000/${result.item_img}">

    <form action="/next" method="POST">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Next">
    </form>

    <form action="/previous" method="POST">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Previous">
    </form>

    <form action="/buy" method="POST">
    <h5>item quantity</h5>
    <input type="text" id="item_quantity" name="item_quantity">
    <input type="hidden" id="itemname" name="item_name" value="${result.item_name}">
    <input type="submit" value="Buy">
    </form>
    `)
  }
})

router.post('/buy',(req,res)=>{

  if(req.body,jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email==undefined)
  {
    res.send('Please sign in')
  }
  else
  {
    Order_History_Handler.add(req.body.item_name,req.body.item_quantity,jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email)
    Order_History_Handler.show()
    res.send('Order Received')
  }
})



router.get('/add_items',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'add_items.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });
})


router.post('/add_items',upload.single('image'),async(req,res)=>{


  let user_Exists=new Promise(function(myResolve,err)
  {
    db.all(`SELECT * FROM UserDatabase WHERE email='${jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email}' AND admin='TRUE'`,(err,row)=>{
        if(row.length==1)
        {
          myResolve(true)
        }
        else if (row.length==0)
        {
          myResolve(false)
        }
        })
  })

    let result = await user_Exists

    if(result==true)
    {
      res.send('Item has been added')
      Request_handler.add(req.body.name,req.body.price,req.file.path)
    }
    else if(result==false)
    {
      let filePath='./'+req.file.path
      fs.unlinkSync(filePath)
      res.send('Item cant be added as User is not an Admin')
    }


})


router.get('/delete_items',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'delete_items.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})



router.post('/delete_items',async(req,res)=>{

  let user_Exists=new Promise(function(myResolve,err)
  {
    db.all(`SELECT * FROM UserDatabase WHERE email='${jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email}' AND admin='TRUE'`,(err,row)=>{
        if(row.length==1)
        {
          myResolve(true)
        }
        else if (row.length==0)
        {
          myResolve(false)
        }
        })
  })

    let result = await user_Exists

    if(result==true)
    {
      res.send('User is Admin')
      Request_handler.delete_items(req.body.name)
    }
    else if(result==false)
    {
      res.send('User is not an Admin')
    }

})




module.exports=router;
